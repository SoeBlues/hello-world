#o algoritimo começa com 2 variaveis tamanho para linha e tamanhoc para colunas.
tamanho = int(input("Informe o tamanho da linha: "))
tamanhoc = int(input("Informe o tamanho da coluna: "))
print()
#algoritimo para criar o tamanho da matriz
matriz = []*tamanho
for i in range(tamanho):
    matriz.append([0]*tamanhoc)
#
cont = 0
for linha in range(tamanho):
    for coluna in range(tamanhoc):
        if cont < 10:
            n = "0%d" %cont
            matriz[linha][coluna] = n
            cont += 1
        else:
            matriz[linha][coluna] = cont
            cont += 1
            
for linha1 in matriz:
    linha = ""
    for l in linha1:
        linha = linha +" "+str(l)
    print(linha)

print()

comprados = []
while True:
    print("Bem vindo ao sistema de venda de ingressos. \nEscolha a operação:")
    n1 = int(input("1- Comprar ingressos \n2- Devolver ingressos \n3- Resumo das vendas \n4- sair \nDigite sua escolha:"))
    
    if n1 == 1:
        
        for linha1 in matriz:
            linha = ""
            for l in linha1:
                linha = linha +" "+str(l)
            print(linha)
        
        acentos = input("Quais assentos deseja comprar:").split(",")
        for i in acentos:
            for n in comprados:
                if i == n:
                    print("O assento %s está ocupado e não poderá ser comprado" %i)
            comprados.append(i)
        
                
        for c in acentos:
            c = int(c)
            if c < 10:
                c = "0%d" %c
                

                
            for i in matriz:
                for p in i:
                    
        
                    if p == c:
                        v = i.index(p)
                        i = matriz.index(i)
                        matriz[i][v] = "XX"
        for linha1 in matriz:
            linha = ""
            for l in linha1:
                linha = linha +" "+str(l)
            print(linha)
        print()
        
    if n1 == 4:
        break        